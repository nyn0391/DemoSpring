package com.accenture.lkm.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.lkm.model.Employee;

@RestController
// extends @Controller
// object are automaticaly convereted to JSON or XML
public class EmployeeController {
	
	@RequestMapping(value="emp/controller/json/getDetails",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Employee>> getEmployeeDetails(){
		
		List <Employee> listEmployee = new ArrayList<Employee>();
		listEmployee.add(new Employee("Jack",10001,12345.6,1001));
		listEmployee.add(new Employee("Justin",10002,12345.6,1002));
		listEmployee.add(new Employee("Eric",10002,12345.6,1003));
		return new ResponseEntity<List<Employee>>(listEmployee, HttpStatus.OK);
		
	}
	@RequestMapping(value="emp/controller/xml/getDetails",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<List<Employee>> getEmployeeDetails2(){
		
		List <Employee> listEmployee = new ArrayList<Employee>();
		listEmployee.add(new Employee("Jack",10001,12345.6,1001));
		listEmployee.add(new Employee("Justin",10002,12345.6,1002));
		listEmployee.add(new Employee("Eric",10002,12345.6,1003));
		return new ResponseEntity<List<Employee>>(listEmployee, HttpStatus.OK);
		
	}
}
